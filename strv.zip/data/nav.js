export const mainNavData= [
    {
        id: 1,
        title: 'Category',
        link: '/',
    },
    {
        id: 2,
        title: 'Courses',
        link: '/',
    },
    {   
        id: 3,
        title: 'Blog',
        link: '/',
    },
]